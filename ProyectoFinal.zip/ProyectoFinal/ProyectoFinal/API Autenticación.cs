﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;

namespace ProyectoFinal
{
    internal class APIAut
    {
        /* try
             {
                 Program.cn.Open("odbcproy", "admin", "admin");
             }
             catch
             {
                 MessageBox.Show("Existe un error con la conexion al servidor. Avise al administrador del programa.");
             }
             Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;*/

       

        public static byte Login (String empleado)//devolver string serializado
        {
            EntidadesJSON.Empleado empleadoo = JsonSerializer.Deserialize<EntidadesJSON.Empleado>(empleado);
            if (Program.cn.State != 1)
            {
               

                try
                {
                    Program.cn.Open("odbcproy", empleadoo.nombre, empleadoo.clave);
                }
                catch
                {
                    return 2;
                }
                Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
                return 1;
            }
            else
            {
                Program.cn.Close();
                try
                {
                    Program.cn.Open("odbcproy", empleadoo.nombre, empleadoo.clave);
                }
                catch
                {
                    return 2;
                }
                Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
                return 1;

            }
        }

        public static String Identificacion (String sql)//sql en capa de negocio, la api solo serializa o deserealiza
        {

            ADODB.Recordset rs = new ADODB.Recordset();
            Object filasAfectadas;
            try
            {
                rs = Program.cn.Execute(sql, out filasAfectadas);
            }
            catch
            {
                return "error";
            }
            if (rs.RecordCount > 0)
            {
                String rol = Convert.ToString(rs.Fields[0].Value);
                return rol;
            }
            else
                return "none";
        }
    }
}
