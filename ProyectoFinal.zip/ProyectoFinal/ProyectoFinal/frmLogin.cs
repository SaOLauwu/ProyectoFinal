﻿using System.Text.Json;
namespace ProyectoFinal
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            int ci;
            String nombre = txtboxNombre.Text;
            String apellido = txtBoxApellido.Text;
            String pass = txtboxPass.Text;
            if (!int.TryParse(txtboxCi.Text, out ci))
            {
                MessageBox.Show("El valor ingresado debe ser numerico, sin puntos ni guiones.");
                return;
            }
            else
            {
                EntidadesJSON.Empleado empleado = new EntidadesJSON.Empleado();
                empleado.ci = ci;
                empleado.nombre = nombre;
                empleado.apellido = apellido;
                empleado.rol = "null";
                empleado.clave = pass;
                string empleadoserializado = JsonSerializer.Serialize(empleado);
                switch (APIAut.Login(empleadoserializado))
                {
                    case 1:
                        if (Program.login(empleadoserializado) == 0)
                        {
                            this.Close();
                        }
                        else
                            MessageBox.Show("Existe un error con el rol de este usuario. Avise a un administrador.");
                        break;
                    case 2:
                        MessageBox.Show("Su combinación de nombre y contraseña es incorrecta.");
                        return;
                }


            }


        }

        private void frmLogin_Load(object sender, EventArgs e)
        {

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
